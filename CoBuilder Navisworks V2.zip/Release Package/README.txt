To Install this please unzip the 'Cobuilder for Navisworks' folder to a desired location
then click 2016 for Navisworks 2016 or 2017 for navisworks 2017

this will copy the required folder to the relevent navisworks plugin directory.